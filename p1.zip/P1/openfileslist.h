#ifndef OPENFILESLIST_H
#define OPENFILESLIST_H

#include "listasimple.h"
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits.h>
#include <inttypes.h>

#define MAXFILENAME 1024

typedef struct OpenFile{
	int df;
	int mode;
	char name[MAXFILENAME];
	}OpenFile;

int OpenFilesAdd(int df, int mode,const char name[]);
int OpenFilesDel(int df);
int OpenFilesInit();
void OpenFilesList();
OpenFile* OpenFilesGet(int df);
void OpenFilesClear();


#endif

