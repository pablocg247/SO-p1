	#include "ejemplo.h"
	
void AniadirAlPath(char *dir)
{
    if (dir==NULL)
        PathPrint();
    else if (PathAdd(dir)==-1)
        perror("Imposible aniadir");
}

void EliminarDelPath(char *dir)
{
    if (dir==NULL)
        PathPrint();
    else if (PathDel(dir)==-1)
        perror("Imposible eliminar");
}


void MostrarDirActual()
{
   char dir[MAXNOMBRE];
   
    if (getcwd(dir,MAXNOMBRE)==NULL)
	perror("Imposible obtener directorio");
    else
       printf ("%s\n",dir);
}

int ComprobarSegundoPlano (char *tr[])
{
    int i;
    for (i=0; tr[i]!=NULL;i++)
        if (!strcmp(tr[i],"&")){ /*& indica segundo plano*/ 
            tr[i]=NULL;         /*es el ultimo argumento*/
            return i;       /*si solo hay un & no se ejecuta nada en pplano*/
            }
    return 0;
}


void Proceso (char *tr[], int splano)
{
   pid_t pid;
   void Cmd_exec (char **);
   int background=splano || ComprobarSegundoPlano(tr);
   if ((pid=fork())==-1){
        perror ("Imposible crear proceso");
        return;
        }
  if (pid==0){  /*proceso hijo*/
    Cmd_exec (tr);
    exit(255); /*por si falla exec*/
    }
  if (!background) 
    waitpid(pid,NULL,0);
}

/*********************************************/
/*************COMANDOS DEL SHELL************************/
void Cmd_fin (char * arg[])  /*todos los cmd_ comparten prototipo*/
{                            /*reciben los mismos parametros aunque no los usen*/
	OpenFilesClear();
	PathClear();
    exit(0);
}

void Cmd_autores(char *arg[])
{
    if (arg[0] == NULL) {
        printf("Mauro Fernandez Perez: mauro.fernandez.perez\n");
        printf("Pablo Carril Gontan: p.carril\n");
    }

    else if (!strcmp(arg[0], "-l")) {
        printf("mauro.fernandez.perez\n");
        printf("p.carril\n");
    }
    else if (!strcmp(arg[0], "-n")) {
        printf("Mauro Fernandez Perez\n");
        printf("Pablo Carril Gontan\n");
    }
}

void Cmd_exec (char *arg[])
{
  if (execv(Ejecutable(arg[0]),arg)==-1)
	perror ("Imposible ejecutar");
}

void Cmd_splano (char *arg[])
{
  Proceso (arg,1);
}
void Cmd_pplano (char *arg[])
{
  Proceso(arg,0);
}

void Cmd_chdir (char * arg[])
{
   if (arg[0]==NULL)
      MostrarDirActual();
   else if (chdir(arg[0])==-1)
      perror("Imposible cambiar directorio");
}

void Cmd_pwd(char * arg[])
{
	if (arg[0] != NULL) {
    	printf("pwd: los argumentos que no son opciones no seran tenidos en cuenta)\n");
    	return;
	}
    MostrarDirActual();
}

void Cmd_pid(char *arg[])
{
    if (arg[0] != NULL && !strcmp(arg[0], "-p")) {
        printf("Pid del padre del shell: %d\n", (int)getppid());
    }
    else {
        printf("Pid de shell: %d\n", (int)getpid());
    }
}

void Cmd_where (char *args[])
{
    if (args[0]==NULL)
        printf("Uso: where ejecutable. Indica donde ejecutable está en el path\n");
    else
        printf ("%s\n",Ejecutable (args[0]));
}


void Cmd_path(char *arg[])
{
    if (arg[0]==NULL)
        PathPrint();
    else if (!strcmp(arg[0],"-add"))
        AniadirAlPath (arg[1]);
    else if (!strcmp(arg[0],"-del"))
        EliminarDelPath (arg[1]);
    else if (!strcmp(arg[0],"-show"))
        PathPrint ();
    else if (!strcmp(arg[0],"-clear"))
        PathClear ();
    else if (!strcmp(arg[0],"-import"))
        PathAddPath ();
    else printf ("Opciones validas: -add|-del|-show|-clear|-import\n");
} 
	
void Cmd_importpath (char *arg[])
{
    PathAddPath();
}

void Cmd_date(char *arg[])
{
    time_t ahora;
    struct tm *fecha;
    char texto[80];
    const char *formato;

    if (arg[0] == NULL)
        formato = "%H:%M:%S\n%d/%m/%Y";
    else if (!strcmp(arg[0], "-d"))
        formato = "%d/%m/%Y";
    else if (!strcmp(arg[0], "-t"))
        formato = "%H:%M:%S";
    else
		return; 

    ahora = time(NULL);

    if (ahora == (time_t)-1) {
        perror("Imposible obtener fecha y hora");
        return;
    }

    fecha = localtime(&ahora);

    if (fecha == NULL) {
        perror("Imposible convertir fecha y hora");
        return;
    }

    if (strftime(texto, sizeof(texto), formato, fecha) == 0) {
        printf("No se pudo representar la fecha\n");
        return;
    }

    printf("%s\n", texto);
}

void Cmd_sysinfo(char *arg[])
{
    struct utsname datos;

    if (uname(&datos) == -1) {
        perror("Imposible obtener informacion del sistema");
        return;
    }

   printf("%s (%s), OS: %s-%s-%s\n",
           datos.nodename,
           datos.machine,
           datos.sysname,
           datos.release,
           datos.version);
}

struct COMANDO{
  char * nombre;
  void (*funcion)(char**);
  char * help;
};

extern struct COMANDO C[];

void Cmd_help(char *arg[])
{
    if (arg[0] == NULL) {
        printf("Comandos disponibles:");

        for (int i = 0; C[i].nombre != NULL; i++) {
            printf(" %s", C[i].nombre);
        }

        printf("\n");
        return;
    }

    for (int i = 0; C[i].nombre != NULL; i++) {
        if (!strcmp(arg[0], C[i].nombre)) {
            printf("%s\n", C[i].help);
            return;
        }
    }

    printf("%s: no encontrado\n", arg[0]);
}

static int LeerNumero(const char *texto, intmax_t *numero)
{
    char *fin;

    errno = 0;
    *numero = strtoimax(texto, &fin, 10);

    if (texto == fin || *fin != '\0' || errno == ERANGE) {
        printf("Numero no valido: %s\n", texto);
        return 0;
    }

    return 1;
}

static int LeerDescriptor(const char *texto, int *df)
{
    intmax_t numero;

    if (!LeerNumero(texto, &numero))
        return 0;

    if (numero < 0 || numero > INT_MAX) {
        printf("Descriptor fuera de rango\n");
        return 0;
    }

    *df = (int)numero;
    return 1;
}

void Cmd_open(char *tr[])
{
    int i, df, mode = 0;

    if (tr[0] == NULL) {
        OpenFilesList();
        return;
    }

    for (i = 1; tr[i] != NULL; i++) {
        if (!strcmp(tr[i], "cr")) mode |= O_CREAT;
        else if (!strcmp(tr[i], "ex")) mode |= O_EXCL;
        else if (!strcmp(tr[i], "ro")) mode |= O_RDONLY;
        else if (!strcmp(tr[i], "wo")) mode |= O_WRONLY;
        else if (!strcmp(tr[i], "rw")) mode |= O_RDWR;
        else if (!strcmp(tr[i], "ap")) mode |= O_APPEND;
        else if (!strcmp(tr[i], "tr")) mode |= O_TRUNC;
        else
            break;
    }

    df = open(tr[0], mode, 0777);

    if (df == -1) {
        perror("Imposible abrir fichero");
        return;
    }

    if (OpenFilesAdd(df, mode, tr[0]) == -1) {
        perror("Imposible aniadir entrada a la tabla ficheros abiertos");

        if (close(df) == -1)
            perror("Imposible cerrar descriptor");

        return;
    }

    printf("Anadida entrada %d a la tabla ficheros abiertos\n", df);
}

//Funcion no terminada al no estar implementada la funcionalidad de mapeado
static int EstaMapeado(int df)
{
    (void)df;
    return 0;
}

void Cmd_close(char *tr[])
{
    int df;
    int forzar;
    intmax_t numero;

    if (tr[0] == NULL) {
        OpenFilesList();
        return;
    }

    if (!LeerNumero(tr[0], &numero))
        return;

    if (numero < 0) {
        OpenFilesList();
        return;
    }

    if (numero > INT_MAX) {
        printf("Descriptor fuera de rango\n");
        return;
    }

    df = (int)numero;

    forzar = tr[1] != NULL && !strcmp(tr[1], "-f");

    if (!forzar && EstaMapeado(df)) {
        printf("Descriptor %d corresponde a un mapeo activo. " "Usa 'close %d -f' para forzar\n", df, df);
        return;
    }

    if (close(df) == -1) {
        perror("Imposible cerrar descriptor");
        return;
    }
	
    OpenFilesDel(df);
}

void Cmd_listopen(char *tr[])
{
    OpenFilesList();
}

void Cmd_dup(char *tr[])
{
    int df, duplicado, mode;
    intmax_t numero;
    char aux[MAXFILENAME + 40];
    const char *nombre;
    OpenFile *f;

    if (tr[0] == NULL) {
        OpenFilesList();
        return;
    }

    if (!LeerNumero(tr[0], &numero))
        return;

    if (numero < 0) {
        OpenFilesList();
        return;
    }

    if (numero > INT_MAX) {
        printf("Descriptor fuera de rango\n");
        return;
    }

    df = (int)numero;

    duplicado = dup(df);

    if (duplicado == -1) {
        perror("Imposible duplicar descriptor");
        return;
    }

    f = OpenFilesGet(df);
    nombre = (f != NULL) ? f->name : "desconocido";

    snprintf(aux, sizeof(aux), "duplicado de %d (%s)", df, nombre);

    mode = fcntl(duplicado, F_GETFL);

    if (mode == -1) {
        perror("Imposible obtener modo del descriptor");

        if (close(duplicado) == -1)
            perror("Imposible cerrar descriptor");

        return;
    }

    if (OpenFilesAdd(duplicado, mode, aux) == -1) {
        perror("Imposible anadir a la lista de ficheros abiertos");

        if (close(duplicado) == -1)
            perror("Imposible cerrar descriptor");
    }
}

void Cmd_lseek(char *arg[])
{
    int df, referencia = SEEK_SET;
    intmax_t numero;
    off_t posicion, resultado;

    if (arg[0] == NULL || arg[1] == NULL) {
        printf("Parametros incorrectos\n");
        return;
    }

    if (!LeerDescriptor(arg[0], &df) ||
        !LeerNumero(arg[1], &numero)) {
        return;
    }

    posicion = (off_t)numero;

    if ((intmax_t)posicion != numero) {
        printf("Posicion fuera de rango\n");
        return;
    }

    if (arg[2] != NULL) {
        if (!strcmp(arg[2], "SEEK_CUR"))
            referencia = SEEK_CUR;
        else if (!strcmp(arg[2], "SEEK_END"))
            referencia = SEEK_END;
    }

    resultado = lseek(df, posicion, referencia);

    if (resultado == (off_t)-1) {
        printf("Error al intentar posicionar el descriptor %d " "en el offset  %jd: %s\n", df, (intmax_t)posicion, strerror(errno));
    }
    else {
        printf("Descriptor %d posicionado en %jd\n", df, (intmax_t)resultado);
    }
}

void Cmd_writestr(char *arg[])
{
    int df;
    size_t longitud, total;
    ssize_t escritos;
    const char *texto;

    if (arg[0] == NULL || arg[1] == NULL) {
        printf("Parametros incorrectos\n");
        return;
    }

    if (!LeerDescriptor(arg[0], &df))
        return;

    for (int i = 1; arg[i] != NULL; i++) {

        for (int parte = 0; parte < 2; parte++) {
            if (parte == 0) {
                texto = arg[i];
            }
            else {
                if (arg[i + 1] == NULL)
                    break;

                texto = " ";
            }

            longitud = strlen(texto);
            total = 0;

            while (total < longitud) {
                escritos = write(df, texto + total, longitud - total);

                if (escritos == -1) {
                    if (errno == EINTR)
                        continue;

                    perror("Imposible escribir");
                    return;
                }

                if (escritos == 0) {
                    printf("No se pudo completar la escritura\n");
                    return;
                }

                total += (size_t)escritos;
            }
        }
    }
}

void Cmd_readstr(char *arg[])
{
    int df;
    intmax_t numero;
    size_t cantidad;
    ssize_t leidos;
    char *texto;

    if (arg[0] == NULL || arg[1] == NULL) {
        printf("Parametros incorrectos\n");
        return;
    }

    if (!LeerDescriptor(arg[0], &df) ||
        !LeerNumero(arg[1], &numero))
        return;

    if (numero < 0 ||
        (uintmax_t)numero > (uintmax_t)SSIZE_MAX ||
        (uintmax_t)numero > (uintmax_t)(SIZE_MAX - 1)) {
        printf("Cantidad fuera de rango\n");
        return;
    }

    cantidad = (size_t)numero;
    texto = malloc(cantidad + 1);

    if (texto == NULL) {
        perror("Imposible reservar memoria");
        return;
    }

    do {
        leidos = read(df, texto, cantidad);
    } while (leidos == -1 && errno == EINTR);

    if (leidos == -1) {
        perror("Imposible leer");
    }
    else {
        texto[leidos] = '\0';

        printf("Leidos %zd bytes del descriptor %d\n", leidos, df);
        printf("%s\n", texto);
    }

    free(texto);
}

void Cmd_makefile(char *arg[])
{
    int df;

    if (arg[0] == NULL) {
        MostrarDirActual();
        return;
    }

    df = open(arg[0], O_WRONLY | O_CREAT | O_EXCL, 0777);

    if (df == -1) {
        perror(arg[0]);
        return;
    }

    if (close(df) == -1)
        perror("Imposible cerrar el fichero creado");
}

void Cmd_makedir(char *arg[])
{
    if (arg[0] == NULL) {
        MostrarDirActual();
        return;
    }

    if (mkdir(arg[0], 0777) == -1)
        perror(arg[0]);
}

static char *CopiarRuta(const char *ruta)
{
    char *copia = strdup(ruta);
    size_t n;

    if (copia == NULL) {
        perror("Imposible copiar ruta");
        return NULL;
    }

    n = strlen(copia);

    while (n > 1 && copia[n - 1] == '/')
        copia[--n] = '\0';

    return copia;
}


void Cmd_delete(char *arg[])
{
    struct stat datos;
    int i, resultado;
    char *ruta;

    if (arg[0] == NULL) {
        MostrarDirActual();
        return;
    }

    for (i = 0; arg[i] != NULL; i++) {
        ruta = CopiarRuta(arg[i]);

        if (ruta == NULL)
            continue;

        if (lstat(ruta, &datos) == -1) {
            perror(ruta);
        }
        else {
            if (S_ISDIR(datos.st_mode))
                resultado = rmdir(ruta);
            else
                resultado = unlink(ruta);

            if (resultado == -1)
                perror(ruta);
        }

        free(ruta);
    }
}

static int BorrarArbol(const char *ruta)
{
    struct stat datos;
    DIR *directorio;
    struct dirent *entrada;
    char *hijo;
    size_t tam;
    int correcto = 1;

    if (lstat(ruta, &datos) == -1) {
        perror(ruta);
        return 0;
    }

    if (!S_ISDIR(datos.st_mode)) {
        if (unlink(ruta) == -1) {
            perror(ruta);
            return 0;
        }

        return 1;
    }

    directorio = opendir(ruta);

    if (directorio == NULL) {
        perror(ruta);
        return 0;
    }

    while (1) {
        errno = 0;
        entrada = readdir(directorio);

        if (entrada == NULL) {
            if (errno != 0) {
                perror(ruta);
                correcto = 0;
            }

            break;
        }

        if (!strcmp(entrada->d_name, ".") ||
            !strcmp(entrada->d_name, ".."))
            continue;

        tam = strlen(ruta) + strlen(entrada->d_name) + 2;
        hijo = malloc(tam);

        if (hijo == NULL) {
            perror("Imposible reservar memoria");
            correcto = 0;
            break;
        }

        snprintf(hijo, tam, "%s/%s", ruta, entrada->d_name);

        if (!BorrarArbol(hijo))
            correcto = 0;

        free(hijo);
    }

    if (closedir(directorio) == -1) {
        perror(ruta);
        correcto = 0;
    }

    if (correcto && rmdir(ruta) == -1) {
        perror(ruta);
        correcto = 0;
    }

    return correcto;
}


void Cmd_deltree(char *arg[])
{
    int i;
    char *ruta;

    if (arg[0] == NULL) {
        printf("Uso: deltree nombre1 nombre2 ...\n");
        return;
    }

    for (i = 0; arg[i] != NULL; i++) {
        ruta = CopiarRuta(arg[i]);

        if (ruta == NULL)
            continue;

        BorrarArbol(ruta);
        free(ruta);
    }
}

char LetraTF (mode_t m)
{
     switch (m&S_IFMT) { /*and bit a bit con los bits de formato,0170000 */
        case S_IFSOCK: return 's'; /*socket */
        case S_IFLNK: return 'l'; /*symbolic link*/
        case S_IFREG: return '-'; /* fichero normal*/
        case S_IFBLK: return 'b'; /*block device*/
        case S_IFDIR: return 'd'; /*directorio */ 
        case S_IFCHR: return 'c'; /*char device*/
        case S_IFIFO: return 'p'; /*pipe*/
        default: return '?'; /*desconocido, no deberia aparecer*/
     }
}

char * ConvierteModo3 (mode_t m)
{
    char *permisos;

    if ((permisos = (char *) malloc(12)) == NULL)
        return NULL;
    strcpy(permisos, "---------- ");

    permisos[0] = LetraTF(m);
    if (m & S_IRUSR) permisos[1] = 'r';
    if (m & S_IWUSR) permisos[2] = 'w';
    if (m & S_IXUSR) permisos[3] = 'x';
    if (m & S_IRGRP) permisos[4] = 'r';
    if (m & S_IWGRP) permisos[5] = 'w';
    if (m & S_IXGRP) permisos[6] = 'x';
    if (m & S_IROTH) permisos[7] = 'r';
    if (m & S_IWOTH) permisos[8] = 'w';
    if (m & S_IXOTH) permisos[9] = 'x';
    if (m & S_ISUID) permisos[3] = (m & S_IXUSR) ? 's' : 'S';
    if (m & S_ISGID) permisos[6] = (m & S_IXGRP) ? 's' : 'S';
    if (m & S_ISVTX) permisos[9] = (m & S_IXOTH) ? 't' : 'T';
    
    return permisos;
}

static void ListarFichero(const char *ruta, const char *nombre, int long_mode, int link_mode, int acc_mode)
{
    struct stat s;
    char destino[PATH_MAX];
    char enlace_str[PATH_MAX + 5] = "";

    if (lstat(ruta, &s) == -1) {
        perror(ruta);
        return;
    }

    if (link_mode && S_ISLNK(s.st_mode)) {
        ssize_t n = readlink(ruta, destino, sizeof(destino) - 1);

        if (n == -1) {
            perror(ruta);
            return;
        }

        destino[n] = '\0';
        snprintf(enlace_str, sizeof(enlace_str), " -> %s", destino);
    }

    if (!long_mode) {
        printf("%8jd  %s%s\n", (intmax_t)s.st_size, nombre, enlace_str);
        return;
    }

    time_t t = acc_mode ? s.st_atime : s.st_mtime;
    struct tm *tm_info = localtime(&t);
    char fecha[32];

    if (tm_info == NULL) {
        perror("Imposible convertir fecha");
        return;
    }

    if (strftime(fecha, sizeof(fecha),
                 "%Y/%m/%d-%H:%M", tm_info) == 0) {
        printf("No se pudo representar la fecha\n");
        return;
    }

    struct passwd *p = getpwuid(s.st_uid);
    struct group *g = getgrgid(s.st_gid);

    char uid[32], gid[32];

    snprintf(uid, sizeof(uid), "%ju", (uintmax_t)s.st_uid);
    snprintf(gid, sizeof(gid), "%ju", (uintmax_t)s.st_gid);

    const char *user = (p != NULL) ? p->pw_name : uid;
    const char *group = (g != NULL) ? g->gr_name : gid;

    char *permisos = ConvierteModo3(s.st_mode);

    if (permisos == NULL) {
        perror("Imposible convertir permisos");
        return;
    }

    printf("%s %3ju (%8ju) %8s %8s %s%8jd %s%s\n",
           fecha,
           (uintmax_t)s.st_nlink,
           (uintmax_t)s.st_ino,
           user,
           group,
           permisos,
           (intmax_t)s.st_size,
           nombre,
           enlace_str);

    free(permisos);
}

void Cmd_listfile(char *arg[])
{
    int long_mode = 0, link_mode = 0, acc_mode = 0;
    int i;

    for (i = 0; arg[i] != NULL; i++) {
        if (!strcmp(arg[i], "-long")) {
            long_mode = 1;
        }
        else if (!strcmp(arg[i], "-link")) {
            link_mode = 1;
        }
        else if (!strcmp(arg[i], "-acc")) {
            acc_mode = 1;
        }
        else {
            break;
        }
    }

    if (arg[i] == NULL) {
        MostrarDirActual();
        return;
    }

    for (; arg[i] != NULL; i++) {
        ListarFichero(arg[i], arg[i], long_mode, link_mode, acc_mode);
    }
}

int EsDirectorio (char * dir)          /*para saber si algo es directorio o no*/
{
  struct stat s;
  if (lstat(dir,&s)==-1)       /*si no puedo acceder: para mi no es directorio*/
        return 0;
  return (S_ISDIR(s.st_mode));
}

static void ListarDirectorio(const char *dirpath,
                            int reca, int recb, int hid,
                            int long_m, int link_m, int acc_m)
{
    DIR *dir;
    struct dirent *ent;
    struct stat datos;
    char ruta[4096];
    int len;

    if (recb)
        reca = 0;

    /* Recorrer subdirectorios antes del listado */
    if (recb) {
        dir = opendir(dirpath);

        if (dir == NULL) {
            perror(dirpath);
            return;
        }

        while (1) {
            errno = 0;
            ent = readdir(dir);

            if (ent == NULL) {
                if (errno != 0)
                    perror(dirpath);
                break;
            }

            if (!hid && ent->d_name[0] == '.')
                continue;

            if (!strcmp(ent->d_name, ".") ||
                !strcmp(ent->d_name, ".."))
                continue;

            len = snprintf(ruta, sizeof(ruta),
                           "%s/%s", dirpath, ent->d_name);

            if (len < 0 || (size_t)len >= sizeof(ruta)) {
                printf("No se pudo construir la ruta: %s/%s\n",
                       dirpath, ent->d_name);
                continue;
            }

            if (lstat(ruta, &datos) == -1) {
                perror(ruta);
                continue;
            }

            if (S_ISDIR(datos.st_mode))
                ListarDirectorio(ruta, reca, recb, hid,
                                 long_m, link_m, acc_m);
        }

        if (closedir(dir) == -1)
            perror(dirpath);
    }

    /* Mostrar el contenido del directorio */
    dir = opendir(dirpath);

    if (dir == NULL) {
        perror(dirpath);
        return;
    }

    printf("************%s\n", dirpath);

    while (1) {
        errno = 0;
        ent = readdir(dir);

        if (ent == NULL) {
            if (errno != 0)
                perror(dirpath);
            break;
        }

        if (!hid && ent->d_name[0] == '.')
            continue;

        len = snprintf(ruta, sizeof(ruta),
                       "%s/%s", dirpath, ent->d_name);

        if (len < 0 || (size_t)len >= sizeof(ruta)) {
            printf("No se pudo construir la ruta: %s/%s\n",
                   dirpath, ent->d_name);
            continue;
        }

        ListarFichero(ruta, ent->d_name,
                     long_m, link_m, acc_m);
    }

    if (closedir(dir) == -1)
        perror(dirpath);

    /* Recorrer subdirectorios después del listado */
    if (reca) {
        dir = opendir(dirpath);

        if (dir == NULL) {
            perror(dirpath);
            return;
        }

        while (1) {
            errno = 0;
            ent = readdir(dir);

            if (ent == NULL) {
                if (errno != 0)
                    perror(dirpath);
                break;
            }

            if (!hid && ent->d_name[0] == '.')
                continue;

            if (!strcmp(ent->d_name, ".") ||
                !strcmp(ent->d_name, ".."))
                continue;

            len = snprintf(ruta, sizeof(ruta),
                           "%s/%s", dirpath, ent->d_name);

            if (len < 0 || (size_t)len >= sizeof(ruta)) {
                printf("No se pudo construir la ruta: %s/%s\n",
                       dirpath, ent->d_name);
                continue;
            }

            if (lstat(ruta, &datos) == -1) {
                perror(ruta);
                continue;
            }

            if (S_ISDIR(datos.st_mode))
                ListarDirectorio(ruta, reca, recb, hid,
                                 long_m, link_m, acc_m);
        }

        if (closedir(dir) == -1)
            perror(dirpath);
    }
}

void Cmd_list(char *arg[])
{
    int reca = 0, recb = 0, hid = 0;
    int long_mode = 0, link_mode = 0, acc_mode = 0;
    int i;

    for (i = 0; arg[i] != NULL; i++) {
        if (!strcmp(arg[i], "-reca"))
            reca = 1;
        else if (!strcmp(arg[i], "-recb"))
            recb = 1;
        else if (!strcmp(arg[i], "-hid"))
            hid = 1;
        else if (!strcmp(arg[i], "-long"))
            long_mode = 1;
        else if (!strcmp(arg[i], "-link"))
            link_mode = 1;
        else if (!strcmp(arg[i], "-acc"))
            acc_mode = 1;
        else
            break;
    }

    if (recb)
        reca = 0;

    if (arg[i] == NULL) {
        MostrarDirActual();
        return;
    }

    for (; arg[i] != NULL; i++) {
        if (EsDirectorio(arg[i])) {
            ListarDirectorio(arg[i], reca, recb, hid,
                             long_mode, link_mode, acc_mode);
        }
        else {
            ListarFichero(arg[i], arg[i],
                          long_mode, link_mode, acc_mode);
        }
    }
}
